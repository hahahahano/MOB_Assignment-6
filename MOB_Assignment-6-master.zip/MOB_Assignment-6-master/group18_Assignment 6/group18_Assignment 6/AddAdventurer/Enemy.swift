//
//  enemy.swift
//  group18_Assignment 6
//
//  Created by Mireya Almaraz on 10/27/19.
//  Copyright © 2019 Group 18. All rights reserved.
//

//import Foundation
import UIKit

class Enemy {
    let name: String
    let current_HP: Int
    let total_HP: Int
    let attack: Float
    
    //MARK: Initialization
    init(name: String, currentHP: Int, totalHP: Int, attack: Float) {
        self.name = name
        self.current_HP = currentHP
        self.total_HP = totalHP
        self.attack = attack
    }
}
