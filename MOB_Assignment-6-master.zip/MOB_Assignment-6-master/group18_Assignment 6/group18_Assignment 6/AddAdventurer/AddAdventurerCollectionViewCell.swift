//
//  AddAdventurerCollectionViewCell.swift
//  group18_Assignment 6
//
//  Created by Hoej, Christian R on 10/20/19.
//  Copyright © 2019 Group 18. All rights reserved.
//

import UIKit

class AddAdventurerCollectionViewCell: UICollectionViewCell {
    //MARK: Properties
    @IBOutlet weak var adventurerImageView: UIImageView!
}
