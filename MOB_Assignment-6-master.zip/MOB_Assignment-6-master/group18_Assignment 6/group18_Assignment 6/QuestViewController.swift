//
//  QuestViewController.swift
//  group18_Assignment 6
//
//  Created by Xia, Emily on 10/22/19.
//  Copyright © 2019 Group 18. All rights reserved.
//

import UIKit
import CoreData
import os.log
//import Cocoa

class QuestViewController: UIViewController {
    //MARK: Properties
    @IBOutlet weak var qName: UILabel!
    @IBOutlet weak var qLevel: UILabel!
    @IBOutlet weak var qClass: UILabel!
    @IBOutlet weak var qAttack: UILabel!
    @IBOutlet weak var qHP: UILabel!
    @IBOutlet weak var qImage: UIImageView!
    @IBOutlet weak var questLog: UITextView!
    @IBOutlet weak var endQuest: UIButton!
    
    var adventurer = NSManagedObject()
    var enemy1 = NSManagedObject()
    var adventurerObject:adventurer? = nil
    var enemyObject:Enemy? = nil
    var adventure_act_timer: Timer!
    var enemy_act_timer: Timer!
    var adventurer_act: Int = 15
    var enemy_act: Int = 21
    
    var enemies_defeated: Int = 0
    
    //Enemy attack
    let names = ["Big Bad Wolf", "The Elements", "A Bad Guy"]
     
    lazy var randomName = names.randomElement()!
    let totalHP = Int.random(in: 90..<151)
    lazy var current_HP = totalHP
    lazy var total_HP = totalHP
    let attack = Float.random(in: 2..<5.1)
    
    //MARK: Methods
    //Loading the screen
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let name = adventurer.value(forKey: "name") as? String
        let level = adventurer.value(forKeyPath: "level") as? Int ?? 0
        let Class = adventurer.value(forKeyPath: "adventurerClass") as? String
        let attackFl = adventurer.value(forKeyPath: "attack") as? Float
        let real_attack = String(format: "%.2f", attackFl ?? 0)
        let photo = adventurer.value(forKeyPath: "image") as? UIImage
        
        //let currentHPStatus = adventurer.value(forKeyPath: "currentHP") as? Int
        //let totalHPStatus = adventurer.value(forKeyPath: "totalHP") as? Int
       // let real_HP = (Float(currentHPStatus ?? <#default value#>) / Float(totalHPStatus)) as? Float
        var real_HP: Float? = 0

         if let currentHPStatus = adventurer.value(forKeyPath: "currentHP") as? Int
         , let totalHPStatus = adventurer.value(forKeyPath: "totalHP") as? Int
         {
          real_HP = (Float(currentHPStatus) / Float(totalHPStatus))
            qHP?.text = "\(real_HP)"
         }
        qName?.text = name
        qLevel?.text = "\(level)"
        qClass?.text = Class
        qAttack?.text = real_attack
        qImage?.image = photo
        //qHP?.text = real_HP
        
        //qLevel?.text = "\(adventurer.value(forKeyPath: "level") as? Int ?? 0)"
        //qClass?.text = adventurer.value(forKeyPath: "adventurerClass") as? String
        //qAttack?.text = String(format: "%.2f", attackFl ?? 0)
        //qHP?.text = "\(currentHPStatus ?? 0)"+"/"+"\(totalHPStatus ?? 0)"
        //qImage?.image = adventurer.value(forKeyPath: "image") as? UIImage
        
        enemyObject = Enemy(name: randomName , currentHP: current_HP, totalHP: total_HP, attack: attack)
        adventurerObject = adventurer(name: name, adclass: Class, image: photo, level: level, currentHP: real_HP, attack: real_attack)
        
        // Adventurer and enemy timers initiated as soon as page is loaded
        adventure_act_timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(adventure_action), userInfo: nil, repeats: true )
        
        enemy_act_timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(enemy_action), userInfo: nil, repeats: true)
        
        questLog.text = "Beginning Quest... \n"
    }
    
    //Quest Dialogue
    var text: String = ""
    
    //Quest Timers
    @objc func adventure_action(){
        adventurer_act -= 1
        
        if adventurer_act == 0{
            enemyObject?.current_HP -= adventurerObject.attack
            //if enemy.current_HP <= 0{
            //    adventure_act_timer.invalidate()
            //    enemies_defeated += 1
                //text += /()
            //}
        }
        
    }
    
    //if enemy.currentHP
    
    @objc func enemy_action(){
        enemy_act -= 1
           
        if enemy_act == 0{
            enemy_act_timer.invalidate()
            //adventurer.currentHP -= enemy.attackk
            
        }
           
    }
    
    //Updating the info at the top according to quest (change level, currentHP)
        //Make sure this saves to core data
        //Also make sure that when the person returns to the main screen (the table view) that the current HP returns to total HP (regaining their HP) AND that the new level is updated
    
    //MARK: Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        //Configure the destination view controller only when the end quest button is pressed
        guard let button = sender as? UIButton, button === endQuest else {
            os_log("The End Quest button was not pressed, cancelling quest and progress", log: OSLog.default, type: .debug)
            return
        }
    }
}
